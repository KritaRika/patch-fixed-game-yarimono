import sys

from pm.cli import main

sys.exit(1 if main() else 0)
