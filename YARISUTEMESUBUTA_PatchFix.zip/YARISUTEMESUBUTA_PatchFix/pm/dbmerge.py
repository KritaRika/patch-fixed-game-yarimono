"""Entry-by-entry merge of RPG Maker database JSON: the higher layer wins, lower layers fill gaps."""
import copy


def _empty(x) -> bool:
    return x is None or x == "" or (isinstance(x, dict) and x.get("name", None) == "")


def deep_fill(high, low, path: str, conflicts: list, layer: str = "patch"):
    if isinstance(high, dict) and isinstance(low, dict):
        out = {}
        for k, v in high.items():
            out[k] = deep_fill(v, low[k], f"{path}.{k}", conflicts, layer) if k in low else copy.deepcopy(v)
        for k, v in low.items():
            if k not in high:
                out[k] = copy.deepcopy(v)
        return out
    if isinstance(high, list) and isinstance(low, list):
        out = []
        for i, h in enumerate(high):
            lo = low[i] if i < len(low) else None
            if _empty(h) and not _empty(lo):
                out.append(copy.deepcopy(lo))
            else:
                if not _empty(h) and not _empty(lo) and h != lo:
                    conflicts.append(f"{path}[{i}]: kept {layer}, dropped lower")
                out.append(copy.deepcopy(h))
        out.extend(copy.deepcopy(low[len(high):]))
        return out
    if not _empty(high) and not _empty(low) and high != low:
        conflicts.append(f"{path}: kept {layer}, dropped lower")
    return copy.deepcopy(high)


def merge_layers(versions: list, rel: str):
    """versions: [(layer, data), ...] highest first. Returns (merged, conflicts)."""
    conflicts = []
    layer, merged = versions[0]
    owner = layer
    for low_layer, low in versions[1:]:
        merged = deep_fill(merged, low, rel, conflicts, f"{owner} over {low_layer}")
    return merged, conflicts
