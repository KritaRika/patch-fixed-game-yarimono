"""Where each file comes from, and which layer wins."""
import os
import re
from pathlib import Path

SCRIPT_MIN_VERSION = (4, 0)  # older patches number their plugin scripts differently from Steam
_LABEL = re.compile(r"^v(\d+)\.(\d+)$")


def script_layers_for(patches: dict) -> set:
    """Patch labels (like 'v4.00') whose plugin scripts match Steam's numbering."""
    out = set()
    for label in patches:
        m = _LABEL.match(label)
        if m and (int(m.group(1)), int(m.group(2))) >= SCRIPT_MIN_VERSION:
            out.add(label)
    return out

_SKIP_FILES = {"saveyarimon.txt", ".gitignore", "package.json", "index.html", "v8.log", "js/plugins.js"}
_MAP = re.compile(r"^data(_\w+)?/map\d+\.json$")
_DATA_JSON = re.compile(r"^data(_\w+)?/[^/]+\.json$")


def classify(rel: str) -> str:
    r = rel.replace("\\", "/").lower()
    if r in _SKIP_FILES or r.startswith("save/") or r.endswith(".rpgsave") or r.startswith("js/libs/") \
            or re.match(r"^js/rpg_[^/]+\.js$", r):
        return "skip"
    if r.startswith("js/plugins/") and r.endswith(".js"):
        return "script"
    if _MAP.match(r):
        return "map"
    if _DATA_JSON.match(r):
        return "database"
    return "asset"


def scan(roots: dict) -> dict:
    out = {}
    for layer, root in roots.items():
        root = Path(root)
        for d, _, fs in os.walk(root):
            for f in fs:
                p = Path(d) / f
                rel = p.relative_to(root).as_posix().lower()
                out.setdefault(rel, {})[layer] = p
    return out


def winner(rel: str, sources: dict, order: list, script_layers: set):
    """order: ["steam", patches oldest..newest]. Returns the winning patch layer, or None to keep Steam / skip."""
    kind = classify(rel)
    if kind == "skip":
        return None
    for layer in reversed(order[1:]):
        if layer in sources and (kind != "script" or layer in script_layers):
            return layer
    return None
