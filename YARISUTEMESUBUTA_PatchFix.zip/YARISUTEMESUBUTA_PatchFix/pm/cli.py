﻿"""snapshot / plan / apply / validate / restore."""
import argparse
import hashlib
import json
import os
import shutil
import sys
from collections import Counter
from dataclasses import dataclass
from pathlib import Path

from pm.dbmerge import merge_layers
from pm import locate
from pm.layers import classify, scan, script_layers_for, winner
from pm.validate import validate


@dataclass
class Action:
    rel: str      # path relative to www, spelling of the winning file
    kind: str     # "copy" | "json"
    source: object  # Path for copy, merged data for json
    layer: str
    category: str  # classify() result


def _is_save(rel: str) -> bool:
    """Files the game itself writes: never snapshotted, restored, deleted or overwritten."""
    r = rel.replace("\\", "/").lower()
    return r.startswith("save/") or r.endswith(".rpgsave") or r == "saveyarimon.txt"


def _md5(p: Path) -> str:
    return hashlib.md5(Path(p).read_bytes()).hexdigest()


def _same(a: Path, b: Path) -> bool:
    if a.stat().st_size != b.stat().st_size:
        return False
    return _md5(a) == _md5(b)


def _written_file(snap: Path) -> Path:
    return Path(snap).parent / "written.json"


def _json_bytes(obj) -> bytes:
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def _load(p: Path):
    return json.loads(p.read_text(encoding="utf-8-sig"))


def _added_file(snap: Path) -> Path:
    return Path(snap).parent / "added.txt"


def snapshot(live: Path, snap: Path) -> int:
    live, snap = Path(live), Path(snap)
    if snap.exists():
        return 0
    partial = snap.parent / (snap.name + ".partial")
    if partial.exists():
        shutil.rmtree(partial)
    n = 0
    for d, _, fs in os.walk(live):
        for f in fs:
            p = Path(d) / f
            rel = p.relative_to(live).as_posix()
            if _is_save(rel):
                continue
            dst = partial / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, dst)
            n += 1
    partial.rename(snap)
    return n


def build(snap: Path, patch_roots: dict):
    """Returns (actions that change something vs Steam, database conflicts)."""
    roots = {"steam": Path(snap), **{k: Path(v) for k, v in patch_roots.items()}}
    order = list(roots)  # steam, then patches oldest -> newest (patch_roots insertion order)
    script_layers = script_layers_for(patch_roots)
    actions, conflicts = [], []
    for key, sources in sorted(scan(roots).items()):
        w = winner(key, sources, order, script_layers)
        if w is None:
            continue
        cat = classify(key)
        rel = sources[w].relative_to(roots[w]).as_posix()
        if "steam" in sources:
            rel = sources["steam"].relative_to(roots["steam"]).as_posix()
        if cat == "database":
            versions = [(L, _load(sources[L])) for L in reversed(order) if L in sources]
            merged, c = merge_layers(versions, rel)
            conflicts.extend(c)
            if "steam" in sources and merged == versions[-1][1]:
                continue
            actions.append(Action(rel, "json", merged, w, cat))
        else:
            if "steam" in sources and _same(sources["steam"], sources[w]):
                # The newest patch only re-ships Steam's (censored) image; use an older patch's own version.
                older = [L for L in reversed(order[1:order.index(w)])
                         if cat == "asset" and L in sources and not _same(sources["steam"], sources[L])]
                if not older:
                    continue
                w = older[0]
            actions.append(Action(rel, "copy", sources[w], w, cat))
    return actions, conflicts


def plan_counts(snap: Path, patch_roots: dict) -> Counter:
    actions, _ = build(snap, patch_roots)
    return Counter((a.layer, a.category) for a in actions)


STEAM_CHANGED = """Steam has changed game files since the backup was taken (for example a game update).
Restoring the old backup would bring back old game data, so nothing was changed.
To fix the new Steam version:
  1. In Steam: right-click the game > Properties > Installed Files > Verify integrity of game files
{steps}
Changed files (first 5): """
DEV_STEPS = """  2. Delete the folder {tool}\\steam_original
  3. python -m pm snapshot
  4. python -m pm apply"""
PLAYER_STEPS = """  2. Delete the folder {tool}\\steam_original
  3. Double-click fix_game.bat"""


def restore(live: Path, snap: Path, steps: str = DEV_STEPS) -> None:
    """Return live to the snapshot. Refuses if Steam changed files the tool did not write."""
    live, snap = Path(live), Path(snap)
    if not snap.exists():
        raise SystemExit("No Steam snapshot found; nothing to restore.")
    wf = _written_file(snap)
    written = json.loads(wf.read_text(encoding="utf-8")) if wf.exists() else {}
    todo, foreign = [], []
    for d, _, fs in os.walk(snap):
        for f in fs:
            s = Path(d) / f
            rel = s.relative_to(snap).as_posix()
            if _is_save(rel):
                continue
            dst = live / rel
            if dst.exists() and _same(s, dst):
                continue
            if dst.exists() and written.get(rel) != _md5(dst):
                foreign.append(rel)
            todo.append((s, dst))
    if foreign:
        tool = Path(snap).parent.parent.name
        raise SystemExit(STEAM_CHANGED.format(steps=steps.format(tool=tool)) + ", ".join(foreign[:5]))
    added = _added_file(snap)
    if added.exists():
        for rel in added.read_text(encoding="utf-8").splitlines():
            p = (live / rel)
            if rel and not _is_save(rel) and not Path(rel).is_absolute() and ".." not in rel and p.is_file():
                p.unlink()
    for s, dst in todo:
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(s, dst)
    for p in (added, wf):
        if p.exists():
            p.unlink()


def apply(live: Path, snap: Path, patch_roots: dict, report: Path, steps: str = DEV_STEPS) -> None:
    live, snap, report = Path(live), Path(snap), Path(report)
    if not snap.exists():
        raise SystemExit("No Steam snapshot found. Run 'snapshot' first.")
    restore(live, snap, steps)
    actions, conflicts = build(snap, patch_roots)
    actions = [a for a in actions if not _is_save(a.rel)]  # defense in depth: classify() already skips them
    added = [a.rel for a in actions if not (snap / a.rel).exists()]
    written = {a.rel: (_md5(a.source) if a.kind == "copy" else hashlib.md5(_json_bytes(a.source)).hexdigest())
               for a in actions}
    # record intent before touching anything, so an interrupted apply can still be restored exactly
    _added_file(snap).write_text("\n".join(added), encoding="utf-8")
    _written_file(snap).write_text(json.dumps(written), encoding="utf-8")
    for a in actions:
        dst = live / a.rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        if a.kind == "copy":
            shutil.copy2(a.source, dst)
        else:
            dst.write_bytes(_json_bytes(a.source))
    problems = validate(live)
    counts = Counter((a.layer, a.category) for a in actions)
    over_steam = [c for c in conflicts if c.endswith("over steam, dropped lower")]
    between = Counter(c.split("[")[0].split(":")[0] for c in conflicts if c not in over_steam)
    lines = ["== Files from patches (by layer/kind counts)"]
    lines += [f"   {layer:5} {cat:9} {n}" for (layer, cat), n in sorted(counts.items())]
    lines += [f"   new files (not in Steam): {len(added)}", "",
              f"== Database conflicts: Steam entries overridden by patches: {len(over_steam)}"]
    lines += ["   " + c.replace(", dropped lower", "") for c in over_steam]
    lines += ["", f"== Entries where a newer patch replaced an older patch (counts per file): {sum(between.values())}"]
    lines += [f"   {f}: {n}" for f, n in sorted(between.items())]
    lines += ["", f"== Validation problems: {len(problems)}"] + ["   " + p for p in problems]
    report.parent.mkdir(parents=True, exist_ok=True)
    report.write_text("\n".join(lines) + "\n", encoding="utf-8")


KNOWN_PATCHES = {"v1.19": "main game patch", "v2.19": "DLC1 patch", "v4.00": "DLC2 patch"}
TESTED_STEAM_VERSION = (3, 8)
SPACE_FACTOR = 1.1

PATCHED_GAME = """Your game files were already overwritten by a patch (the game title is "{title}").
The fix needs the original Steam files first, otherwise "undo" would bring back broken files.
  1. In Steam: right-click the game > Properties > Installed Files > Verify integrity of game files
  2. Run fix_game.bat again.
Your saves are not affected by Verify integrity."""


def _say(msg: str) -> None:
    """print() that never crashes on consoles that can't show Japanese / full-width characters."""
    try:
        print(msg)
    except UnicodeEncodeError:
        enc = getattr(sys.stdout, "encoding", None) or "ascii"
        print(msg.encode(enc, "replace").decode(enc, "replace"))


def _paths(game: Path, tool: Path):
    return Path(game) / "data" / "www", Path(tool) / "steam_original" / "www", Path(tool) / "report.txt"


def _tree_size(root: Path) -> int:
    return sum((Path(d) / f).stat().st_size for d, _, fs in os.walk(root) for f in fs)


def _free_bytes(p: Path) -> int:
    return shutil.disk_usage(p).free


def fix(game: Path, tool: Path, free_bytes=_free_bytes) -> int:
    """Snapshot (first time only, with safety checks) and apply. Returns the number of validation problems."""
    live, snap, report = _paths(game, tool)
    skipped = []
    patches = locate.find_patches(game, [tool], skipped)
    for path, title in skipped:
        _say(f"Ignored (not a developer patch, title '{title}'): {path}")
    if not patches:
        raise SystemExit("No patches found. Extract the developer's patch zip files into the game folder "
                         "(do not copy them over the game), then run again.")
    for label, path in patches.items():
        _say(f"Found patch {label} ({KNOWN_PATCHES.get(label, 'unknown patch')}): {path}")
    for label, name in KNOWN_PATCHES.items():
        if label not in patches:
            _say(f"Not found: {name} ({label}). Content from it will be missing.")
    title, version = locate.title_version(live)
    if not snap.exists():
        if locate.is_patched_title(title):
            raise SystemExit(PATCHED_GAME.format(title=title))
        need = int(_tree_size(live) * SPACE_FACTOR)
        if free_bytes(Path(tool)) < need:
            raise SystemExit(f"Not enough free disk space for the backup of the original files: "
                             f"{need / 1e9:.1f} GB needed on the drive of {tool}.")
        _say("Backing up the original Steam files (first run only, takes a few minutes)...")
        snapshot(live, snap)
    steam_title, steam_version = locate.title_version(snap)
    if steam_version != TESTED_STEAM_VERSION:
        _say(f"Warning: this fix was tested with Steam version v3.08; you have '{steam_title}'. "
              "The automatic check below will report any problems.")
    _say("Merging patches into the game (takes a few minutes)...")
    apply(live, snap, patches, report, PLAYER_STEPS)
    problems = validate(live)
    if problems:
        _say(f"Finished, but {len(problems)} problems were found. See {report}")
    else:
        _say("Finished: the game is fixed and the check found no problems.")
    _say(f"Details: {report}\nTo undo: run undo_fix.bat")
    return len(problems)


def undo(game: Path, tool: Path) -> None:
    live, snap, _ = _paths(game, tool)
    restore(live, snap, PLAYER_STEPS)
    _say("Undo finished: the original Steam files are back. Your saves were not touched.")


def main(argv=None) -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except (AttributeError, ValueError):
        pass
    ap = argparse.ArgumentParser(prog="pm")
    ap.add_argument("command", choices=["fix", "undo", "check", "snapshot", "plan", "apply", "validate", "restore"])
    ap.add_argument("--game", help="game folder (found automatically if omitted)")
    ap.add_argument("--tool", help=argparse.SUPPRESS)
    args = ap.parse_args(argv)
    tool = Path(args.tool).resolve() if args.tool else Path(__file__).resolve().parents[1]
    game = Path(args.game).resolve() if args.game else locate.find_game_root(tool)
    LIVE, SNAPSHOT, report = _paths(game, tool)
    if args.command == "fix":
        return fix(game, tool)
    if args.command == "undo":
        undo(game, tool)
        return 0
    if args.command == "check":
        args.command = "validate"
    PATCH_ROOTS = locate.find_patches(game, [tool]) if args.command in ("plan", "apply") else {}
    if args.command == "snapshot":
        _say(f"copied {snapshot(LIVE, SNAPSHOT)} files to {SNAPSHOT}")
    elif args.command == "plan":
        for (layer, cat), n in sorted(plan_counts(SNAPSHOT, PATCH_ROOTS).items()):
            _say(f"{layer:5} {cat:9} {n}")
    elif args.command == "apply":
        apply(LIVE, SNAPSHOT, PATCH_ROOTS, report)
        _say(open(report, encoding="utf-8").read().split("\n== Database conflicts")[0])
        _say(f"full report: {report}")
    elif args.command == "validate":
        probs = validate(LIVE)
        _say("\n".join(probs) or "no problems")
        _say(f"{len(probs)} problems")
        return len(probs)
    elif args.command == "restore":
        restore(LIVE, SNAPSHOT)
        _say("restored Steam files")
    return 0
