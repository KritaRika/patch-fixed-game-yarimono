"""Find the game folder, the developer's patch folders, and their versions."""
import json
import os
import re
from pathlib import Path

PATCH_TITLE_PREFIX = "ヤリステメスブター"
GAME_EXE = "YARISUTEMESUBUTA.exe"
_VERSION = re.compile(r"v(\d+)\.(\d+)")


def _is_game(p: Path) -> bool:
    return (p / GAME_EXE).is_file() and (p / "data" / "www" / "data" / "System.json").is_file()


def find_game_root(start: Path) -> Path:
    p = Path(start).resolve()
    for cand in [p, *list(p.parents)[:3]]:
        if _is_game(cand):
            return cand
    raise SystemExit(
        "Could not find the game.\n"
        "Put the YARISUTEMESUBUTA_PatchFix folder inside your game folder (the folder that has "
        f"{GAME_EXE}), then run it again.\n"
        "Steam: right-click the game > Manage > Browse local files.")


def title_version(www: Path):
    s = json.loads((Path(www) / "data" / "System.json").read_text(encoding="utf-8-sig"))
    title = s.get("gameTitle", "")
    m = _VERSION.search(title)
    return title, ((int(m.group(1)), int(m.group(2))) if m else None)


def is_patched_title(title: str) -> bool:
    return title.startswith(PATCH_TITLE_PREFIX)


def find_patches(game: Path, exclude: list, skipped: list = None) -> dict:
    """Ordered {version label: www root}, oldest first. Game copies that are not developer patches
    (e.g. a backup of the Steam files) are left out and appended to `skipped` as (path, title)."""
    if skipped is None:
        skipped = []
    game = Path(game).resolve()
    skip = {(game / "data").resolve(), *[Path(e).resolve() for e in exclude]}
    found = {}
    for d, dirs, _ in os.walk(game):
        here = Path(d)
        if here.resolve() in skip:
            dirs[:] = []
            continue
        if here.name == "www" and here.parent.name == "data" and (here / "data" / "System.json").is_file():
            dirs[:] = []
            title, ver = title_version(here)
            if ver is None or not is_patched_title(title):
                skipped.append((here, title))
                continue
            label = f"v{ver[0]}.{ver[1]:02d}"
            if label in found:
                raise SystemExit(f"Patch {label} was found twice. Delete one of these folders and run again:\n"
                                 f"  {found[label][1]}\n  {here}")
            found[label] = (ver, here)
    return {label: path for label, (ver, path) in sorted(found.items(), key=lambda kv: kv[1][0])}
