"""Find references in the game data that point at something missing."""
import json
import re
from pathlib import Path

_AUDIO = {241: "bgm", 245: "bgs", 249: "me", 250: "se"}


def _load(p: Path):
    return json.loads(p.read_text(encoding="utf-8-sig"))


def _named(arr, i) -> bool:
    return isinstance(i, int) and 0 < i < len(arr) and arr[i] is not None and arr[i].get("name", "x") != ""


def _asset(www: Path, sub: str, name: str, exts) -> bool:
    return any((www / sub / (name + e)).exists() for e in exts)


def _check_list(cmds, where, www, db, problems):
    for c in cmds or []:
        code, p = c.get("code"), c.get("parameters") or []
        try:
            if code == 117 and not (0 < p[0] < len(db["ce"]) and db["ce"][p[0]] is not None):
                problems.append(f"{where}: common event {p[0]} missing")
            elif code == 126 and not _named(db["items"], p[0]):
                problems.append(f"{where}: item {p[0]} missing")
            elif code == 111 and p[0] == 8 and not _named(db["items"], p[1]):
                problems.append(f"{where}: item {p[1]} missing (condition)")
            elif code == 201 and p[0] == 0:
                m = p[1]
                if not (www / "data" / f"Map{m:03d}.json").exists() or not (0 < m < len(db["maps"]) and db["maps"][m]):
                    problems.append(f"{where}: map {m} missing")
            elif code == 231 and p[1] and not _asset(www, "img/pictures", p[1], (".rpgmvp", ".png")):
                problems.append(f"{where}: picture img/pictures/{p[1]} missing")
            elif code in _AUDIO and p[0] and p[0].get("name") and \
                    not _asset(www, f"audio/{_AUDIO[code]}", p[0]["name"], (".rpgmvo", ".ogg", ".m4a")):
                problems.append(f"{where}: audio/{_AUDIO[code]}/{p[0]['name']} missing")
        except (IndexError, TypeError, AttributeError):
            problems.append(f"{where}: malformed command {code}")


def validate(www: Path) -> list:
    www = Path(www)
    problems = []
    parsed = {}
    for p in sorted(www.glob("data*/*.json")):
        rel = p.relative_to(www).as_posix()
        try:
            parsed[rel] = _load(p)
        except (ValueError, UnicodeDecodeError) as e:
            problems.append(f"{rel}: invalid JSON ({e.__class__.__name__})")
    db = {"items": parsed.get("data/Items.json", []), "maps": parsed.get("data/MapInfos.json", []),
          "ce": parsed.get("data/CommonEvents.json", [])}
    for rel, data in parsed.items():
        if not rel.startswith("data/"):
            continue
        name = rel[5:]
        if re.match(r"^Map\d+\.json$", name):
            for ev in data.get("events") or []:
                if ev:
                    for j, pg in enumerate(ev.get("pages") or []):
                        _check_list(pg.get("list"), f"{rel} ev{ev.get('id')} p{j}", www, db, problems)
        elif name == "CommonEvents.json":
            for ce in data:
                if ce:
                    _check_list(ce.get("list"), f"{rel} ce{ce.get('id')}", www, db, problems)
        elif name == "Troops.json":
            for tr in data:
                if tr:
                    for j, pg in enumerate(tr.get("pages") or []):
                        _check_list(pg.get("list"), f"{rel} troop{tr.get('id')} p{j}", www, db, problems)
    pj = www / "js" / "plugins.js"
    if pj.exists():
        t = pj.read_text(encoding="utf-8-sig")
        try:
            plugins = json.loads(t[t.index("["):t.rindex("]") + 1])
            for pl in plugins:
                if not (www / "js" / "plugins" / f"{pl['name']}.js").exists():
                    problems.append(f"js/plugins.js: js/plugins/{pl['name']}.js missing")
        except ValueError:
            problems.append("js/plugins.js: cannot parse plugin list")
    return problems
