@echo off
setlocal
cd /d "%~dp0"
set "PYTHONDONTWRITEBYTECODE=1"
if not exist "pm\cli.py" goto notunzipped
title YARISUTEMESUBUTA patch fix - undo
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY (
  where python >nul 2>nul && set "PY=python"
)
if not defined PY goto nopython
%PY% -m pm undo
echo.
pause
exit /b

:nopython
echo Python was not found. Python 3.10 or newer is needed:
echo   https://www.python.org/downloads/
echo.
pause
exit /b 1

:notunzipped
echo The tool files were not found next to this file.
echo Unzip the whole YARISUTEMESUBUTA_PatchFix folder into the game folder first,
echo then run this file from there.
echo.
pause
exit /b 1
