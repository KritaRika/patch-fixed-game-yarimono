YARISUTEMESUBUTA Patch Fix
==========================

1. WHAT THIS FIXES
------------------
The developer's content patches were made for older versions of the game. If you copy them over the
current Steam version, items and map entries go missing and the game stops working.
This tool combines the patches with your Steam game properly, so you get the full patch content AND
keep everything the Steam version has.

2. WHAT YOU NEED
----------------
- The game, installed from Steam (main game; DLC1 and DLC2 if you own them).
- The developer's patches, downloaded from the developer's website:
    072 Project_YARISUTEMESUBUTA：Patch        (main game, v1.19)
    072 Project_YARISUTEMESUBUTA_DLC1：Patch   (DLC1, v2.19)
    072 Project_YARISUTEMESUBUTA～DLC2         (DLC2, v4.00)
  You can use only the patches you have. The tool tells you which ones it found.
- Python 3.10 or newer: https://www.python.org/downloads/
  While installing, tick "Add python.exe to PATH".
- About 4.5 GB of free disk space (for a backup of the original game files).

3. HOW TO INSTALL
-----------------
a) Open your game folder: in Steam, right-click the game > Manage > Browse local files.
b) Unzip this "YARISUTEMESUBUTA_PatchFix" folder into the game folder.
   (The game folder is the one that contains YARISUTEMESUBUTA.exe.)
c) Extract each patch zip into the game folder, each into its own folder.
   IMPORTANT: Do NOT copy the patch's "data" folder over the game, even though the patch
   instructions say so. Just leave the extracted patch folders next to the game files.
   Folder names do not matter; the tool recognizes each patch by its version.
d) Open YARISUTEMESUBUTA_PatchFix and double-click fix_game.bat.
   The first run backs up the original game files and takes a few minutes.
e) When it says "Finished", start the game.

4. IF YOU ALREADY COPIED A PATCH OVER THE GAME
---------------------------------------------
The tool will notice and stop. First get the original files back:
in Steam, right-click the game > Properties > Installed Files > Verify integrity of game files.
Then run fix_game.bat again. Your saves are not affected.

5. UNDO
-------
Double-click undo_fix.bat. The original Steam files come back exactly as they were.

6. AFTER A STEAM UPDATE
-----------------------
After the game updates (or after "Verify integrity"), the tool will refuse to run, so that it never
brings back old game files. Then:
  1. In Steam: Verify integrity of game files.
  2. Delete the folder "steam_original" inside YARISUTEMESUBUTA_PatchFix.
  3. Double-click fix_game.bat.

7. YOUR SAVES ARE SAFE
----------------------
The tool never reads, changes, backs up or restores your save files (the "save" folder, any
.rpgsave file, and saveYarimon.txt). The DLC2 patch contains save files of its own; they are never
copied.

8. WHAT THE TOOL DOES
---------------------
- Pictures, sounds and maps: the newest patch that has the file wins. If the newest patch only
  contains a copy of the Steam (censored) picture, the older patch's own picture is used.
- Game data (items, map list, switches, events, monsters, ...): merged entry by entry. Entries that
  only the Steam version has are kept (for example items 38 and 39, which the patches lack).
  Where a patch and Steam disagree, the patch wins. Every such case is listed in report.txt.
- Plugin scripts: taken only from the DLC2 patch (v4.00). The older patches number their scripts
  differently from the Steam version; using them breaks the game.
- Never copied from patches: save files, package.json, index.html, plugins.js, the engine scripts.
- At the end, the tool checks the whole game for links to missing items, maps, events, pictures,
  sounds and scripts, and reports any it finds.

9. ABOUT THIS PACKAGE
---------------------
This package contains only the fix tool. It contains no game files. You still need to own the game
and get the patches from the developer.

10. TROUBLESHOOTING
-------------------
"Could not find the game"
    The YARISUTEMESUBUTA_PatchFix folder is not inside the game folder. Move it there.
"The tool files were not found next to this file"
    You ran fix_game.bat from inside the zip. Unzip the whole folder into the game folder first.
"No patches found"
    Extract the patch zips into the game folder (see 3c).
"Your game files were already overwritten by a patch"
    See section 4.
"Patch vX.XX was found twice"
    The same patch is extracted in two places. Delete one of the folders shown.
"Not enough free disk space"
    Free up the space shown, on the drive where the game is installed.
"Steam has changed game files since the snapshot was taken"
    See section 6.
"Python was not found"
    Install Python (section 2) and tick "Add python.exe to PATH".
